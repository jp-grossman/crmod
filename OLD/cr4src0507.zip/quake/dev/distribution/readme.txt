Title    : ClanRing CRMod++ v4.0 Quake Competition Server
Filename : cralpha3.zip
Version  : 4.0f
Date     : May 3, 1998
Authors  : J.P. Grossman (a.k.a. Mephistopheles) and Paul Baker
Email    : jpg@ai.mit.edu, pbaker@mpog.com
URL      : http://www.mpog.com/clanring/crmod

==============================================================================
This is the ClanRing CRMod++ V4.0 alpha.  It is available for testing 
purposes only.  Do not distribute these files.

Please note that the manual is not complete; it will be updated for the 
public beta release.  Send all bug reports to crbug@mpog.com.
==============================================================================


What is it?
=======================================
ClanRing CRMod++ 4.0 is the result of the integration of several ClanRing Mod
features into the Elohim Server code.

Why do it?
=======================================
Much of the code that was in ClanRing Mod 3.x was very old and outdated.
Adding features to the ClanRing source in it's current state often introduced
many bugs which were incredibly difficult to fix at times, and frankly quite
embarrassing.  The Elohim Server was essentially the same product as the
ClanRing Mod, rewritten and retooled from scratch.  (Instead of a hastily
written server mode with feature after feature added after time). In early
February, J.P. and myself met with each other and talked about joining
our efforts to create the best competition mod out there.  After three
long months, we present to you The ClanRing CRMod++ v4.0 Quake Competition
Server.

Description of Modification
=======================================
progs.dat        - Quake program data file run by the server.
crmod.cfg        - Config file used to set the administrator password
levels.cfg       - Config file used to set the level order
userdefs.cfg     - Config file used to set the MOTD and custom levels
crmake.exe       - Utility to add the userdefs to progs.dat (Win32 build)
crmake.linux     - Utility to add the userdefs to progs.dat (linux build)
entities\*.ent   - Optional entity files
cameras\*.cam    - Optional camera files
readme.txt       - This file

Setup and Installation
=======================================
1. Create a subdirectory in your Quake directory called 'cr4' or whatever
   else you feel like calling it.
   
2. Unzip the contents of cralpha3.zip into this new subdirectory.

3. Edit crmod.cfg, levels.cfg, and userdefs.cfg.

4. Run the crmake utility.  (crmake.exe in Win95/NT or crmake.linux in linux)

5. Start up your quake server with '-game cr4' in the command line replacing
   'cr4' with whatever name you gave your subdirectory.
   
   Example:  winquake.exe -game cr4 -dedicated 14 +sv_aim 2 +noexit 1 +map dm3
             unixded -game cr4 -dedicated 14 +sv_aim 2 +noexit 1 +map dm3
             
Copyright
=======================================
All files included with this modification are Copyright 1998, 
Idle Communications, Inc.

Author Information
=======================================
J.P. Grossman is a second year graduate student at M.I.T. in the department of
Electrical Engineering and Computer Science.  He has been hacking Quake since
Oct. '97 when he began working on the Elohim Server.  J.P. have been hacking
computers in general for 18 years; starting in grade 1 writing BASIC programs
for a VIC-20 and saving them on a tape drive, often accidentally erasing the 
end of the previous program.

Paul Baker is a fourth year computer science student at UCLA-YEAH RIGHT!
Actually, he is currently attending the College of DuPage in Glen Ellyn, IL
after an unsuccessful career at the University of Illinois at Urbana-
Champaign.  He has been working on QuakeC since April of 1997 when he took 
over the ClanRing Mod code from Steven Possehl.  Paul was first introduced to
computers at the age of 10 when he taught himself to write BASIC programs on
an Atari Home Computer.  He also saved many programs to tape, but never
managed to overwrite the ends of previous ones. :)

Acknowledgements
=======================================
It would not have been possible to create this server without the help of
Ignatu (a.k.a. Frank Cabanski) who introduced Paul and J.P. to one another
and for his patience and support throughout these last several months.
WE LOVE YOU FRANKY!  Also, Tovi "Izra'il" Grossman, whose suggestions, 
encouragement and bug reports, starting from the day the Elohim Server was
conceived, were invaluable.  Thanks also to Justin Hays and Dan "Nesta" at
apci for their suggestions and their help with beta testing the Elohim
Server versions 2.0 and up.  A big thanks goes to everyone on EFNet IRC,
especially those in #ClanRing, #ClanChat, and #Club_Bastardo.  Without
those spur of the moment testers, who knows how long this would have
taken.  Another big thanks to Lemurboy (a.k.a. Joel Baxtor) and the rest
of Clan9 for QSmack (http://lemur.stanford.edu/clan9/qsmack/) and their
great suggestions and constant help and testing.

License Agreement
=======================================
This modification if free for public and private NON-COMMERCIAL
use.  To use this modification for COMMERCIAL purposes, you must
contact the Authors, at pbaker@mpog.com. for expressed written
permission.

No modifications can be made to this mod with the exception
of the necessary config files, without expressed written permission
from the Authors.

The ClanRing CRMod++ v4.0 Competition Server may be used on any server
provided that:

	1. No persons shall be charged to play on any server running the mod.
	2. It is not modified in any other ways except those stated in the
	   installation section of this readme file.
	3. No llamas are harmed during the use of the server.

You may not distribute any of the files included with this modification!

If you would like to license the source code to this mod, please also
contact the Authors at pbaker@mpog.com.

Decompiling the progs.dat violates copyright and other applicable laws
and is very, very, very illegal.  So don't do it!

Legal Notice
=======================================
The contents of this file and may change at any time, so don't blink. As with
all other mods, this software is provided "as is".  We are not responsible
for any personal losses or damages caused by this software which include, but
are not limited to, lack of sleep, reduced sex drive, nausea and vomiting,
loss of sight, serious bodily harm, financial destitution, termination of
relationships, death of pets or family members or self, loss of friends,
repetitive strain injury, lowered intelligence, and the complete erasure of 
all hard drive contents.  Of course, you can't wipe a hard drive with QuakeC.
Or can you? ;)